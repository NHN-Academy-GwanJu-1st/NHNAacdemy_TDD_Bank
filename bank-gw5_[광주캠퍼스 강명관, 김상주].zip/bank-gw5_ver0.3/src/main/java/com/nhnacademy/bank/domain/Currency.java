package com.nhnacademy.bank.domain;

public enum Currency {

    CURRENCY_KRW,
    CURRENCY_USD,
    CURRENCY_JPY
}
